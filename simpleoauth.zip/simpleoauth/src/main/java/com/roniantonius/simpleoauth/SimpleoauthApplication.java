package com.roniantonius.simpleoauth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimpleoauthApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimpleoauthApplication.class, args);
	}

}
